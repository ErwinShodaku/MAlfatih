# Portofolio 3D: Muhammad Al Fatih Syabab Mufaakih

Paket siap hosting: satu `index.html` (foto profil sudah tertanam di dalamnya) dan CV PDF di `assets/`.

## Hosting di GitHub Pages
1. Buat repositori baru, unggah seluruh isi folder ini.
2. Settings > Pages > Deploy from a branch > `main` > `/ (root)` > Save.
3. Buka `https://USERNAME.github.io/NAMA-REPO/`.

## Navigasi
Panah, titik, tombol kiri/kanan keyboard, scroll mouse, atau geser jari. Tautan langsung ke slide: `#1` sampai `#8`.

## Mengubah isi
- Juz yang dihafal: variabel `JUZ` di bagian skrip `index.html`.
- Ganti foto: tersedia di `assets/foto.jpg` (untuk pratinjau/berbagi); foto di halaman tertanam, ganti dengan mengganti teks `data:image/jpeg;base64,...` atau ganti menjadi `assets/foto.jpg`.
